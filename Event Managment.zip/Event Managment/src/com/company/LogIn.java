package com.company;
import java.util.*;
public class LogIn {
    Scanner objs=new Scanner(System.in);
    private String lname;
    private String lpassword;
    public void setLoginName(String lname)
    {
        this.lname = lname;

    }
    public void setLoginPassword(String lpassword)
    {
        this.lpassword = lpassword;

    }
    public String getName()
    {
        return lname;
    }
    public String getPassword()
    {
        return lpassword;
    }
    public void TakeLogInInfo()

    {
        System.out.println("Enter your name: ");
        String n=objs.nextLine();
        setLoginName(n);
        System.out.println("Enter your Password: ");
        String p=objs.nextLine();
        setLoginPassword(p);
    }
    public void showInfo()
    {
        System.out.println("Name from login: "+getName());
        System.out.println("password from login: "+getPassword());
    }


}

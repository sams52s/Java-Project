package com.company;
import java.util.*;
public class SignIn {
    Info info=new Info();
    LogIn login=new LogIn();
    Scanner objs=new Scanner(System.in);
    public void setSignIn()
    {

        info.TakeInfo();
        System.out.println("Sign In successful ");
        System.out.println("........................Log In.....................");
        login.TakeLogInInfo();
        VerificationLogInInfo();

    }
    public void VerificationLogInInfo()
    {

        login.showInfo();
        if(info.getName().equals(login.getName())&&info.getPassword().equals(login.getPassword()))
        {
            System.out.println("Login successful ");
            System.out.println("What you want to do?");
            System.out.println("1.Ask for Event management\n2.Want to be a part of Event");
            int c2=objs.nextInt();
            if(c2==1)
            {
                System.out.println("Welcome");
                User user=new User();
                user.user();
            }
            else if(c2==2)
            {
                System.out.println("Welcome.We need you");
                Admin admin=new Admin();
                admin.employee();
            }
            else
            {
                System.out.println("Wrong Info.");
            }
        }
        else
        {
            System.out.println("Wrong Info.");
        }
    }
}

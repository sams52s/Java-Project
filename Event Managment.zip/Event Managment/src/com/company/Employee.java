package com.company;
import java.util.*;
abstract class Employee {
    public abstract void Employees();
    Scanner s1=new Scanner(System.in);
    public void sal()
    {
        Admin admin=new Admin();
        admin.payEmployees();
    }
     public void employee()
     {
         Event e = new Event();
         e.add_details();
         System.out.println("Thank you.\nyour Info have been added");
         System.out.println("1.Show your Info.\n2.Go back\n0.Exit.");
         int i=s1.nextInt();
         switch (i) {
             case 0 ->System.out.println("Thank you.");
             case 1 -> {
                 e.Show();
                 System.out.println("1.Go back\n0.Exit.");
                 int i2=s1.nextInt();
                 if(i2==1)
                 {
                     LogIn l = new LogIn();
                     l.TakeLogInInfo();
                 }
                 else{
                     System.out.println("Thank you.");
                 }
             }

             case 2 -> {
                 LogIn l = new LogIn();
                 l.TakeLogInInfo();
             }
             default -> System.out.println("Wrong Input");
         }
     }
}

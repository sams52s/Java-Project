package com.company;

import java.util.*;
public class Event extends Payment {
    Admin admin=new Admin();
    int price;
    String date;
    Scanner s1=new Scanner(System.in);
    Scanner s2=new Scanner(System.in);
    CreateFile cf = new CreateFile();
    public void add_details() {
        System.out.println("add Details");
        System.out.println("Type: ");
        String i1 = s1.nextLine();
        System.out.println("Activity: ");
        String i2 = s1.nextLine();
        System.out.println("price: ");
        String i3 = s1.nextLine();
        String i0 = "Type:" + i1 + "\nActivity:" + i2 + "\nprice: " + i3;
        cf.writeInFile(i0);
    }

    public void Show() {
        Info info=new Info();
        info.GiveInfo();
        cf.readFromFile();
    }
    public void Events_available()
    {
        String wedding_reception="wedding reception 40000tk";
        String wedding_day="wedding_day 35000tk";
        String Holdi_day="Holdi_day 25000tk";
        String Birthday="Birthday 15000tk";
        String Meeting="Meeting 10000tk";
        admin.Events();
        System.out.println("Enter your date: ");
        date=s1.nextLine();
        if(date.equals("31-12-2020")||date.equals("01-01-2021")){
            System.out.println("Sorry we are booked in this day.");
        }
        else if(date!="31-12-2020"||date!="01-01-2021") {
            System.out.println("We are available in this day.\n");
            System.out.println("1.wedding reception 40000tk\n2.wedding_day 35000tk\n3.Holdi_day 25000tk\n4.Birthday 15000tk\n5.Meeting 10000tk");
            System.out.println("What Event you want?");
            int choice = s2.nextInt();
            switch (choice) {
                case 1 -> {
                    System.out.println("wedding reception 40000tk has been added");
                    System.out.println("Do you want to add Holdi also(1)? or Exit(2)");
                    int c2 = s2.nextInt();
                    if (c2 == 1) {
                        price = 65000;
                        String combo = wedding_reception + "\nAnd\n" + Holdi_day+"\nYou have booked in : "+date+"\nYour total amount: "+price ;
                        cf.writeInFileInfo(combo);
                        System.out.println("Holdi_day 25000tk has been added also");

                    } else {
                        price = 40000;
                        String combo = wedding_reception + "\nYou have booked in : "+date+"\nYour total amount: "+price ;
                        cf.writeInFileInfo(combo);
                        System.out.println("ok Thank you");

                    }
                }
                case 2 -> {

                    System.out.println("wedding_day 35000tk");
                    System.out.println("Do you want to add Holdi also(1)? or Exit(2)");
                    int c2 = s2.nextInt();
                    if (c2 == 1) {
                        price = 60000;
                        String combo = wedding_day + "\nAnd\n" + Holdi_day+"\nYou have booked in : "+date+"\nYour total amount: "+price ;
                        cf.writeInFileInfo(combo);
                        System.out.println("Holdi_day 25000tk has been added also");

                    } else {
                        price = 35000;
                        String combo = wedding_day + "\nYou have booked in : "+date+"\nYour total amount: "+price ;
                        cf.writeInFileInfo(combo);
                        System.out.println("ok Thank you");

                    }
                }
                case 3 -> {
                    price = 25000;
                    String combo =  Holdi_day+"\nYou have booked in : "+date+"\nYour total amount: "+price ;
                    cf.writeInFileInfo(combo );
                    System.out.println("Holdi_day 25000tk has been added");

                }

                case 4 -> {
                    price = 15000;
                    String combo =Birthday+"\nYou have booked in : "+date+"\nYour total amount: "+price ;
                    cf.writeInFileInfo(Birthday);
                    System.out.println("Birthday 15000tk has been added");

                }
                case 5 -> {
                    price = 10000;
                    String combo =Meeting+"\nYou have booked in : "+date+"\nYour total amount: "+price ;
                    cf.writeInFileInfo(combo);
                    System.out.println("Meeting 10000tk has been added");

                }
                default -> System.out.println("Wrong Input sorry");
            }
            System.out.println("Your Event will Manage by team1: \n");
            admin.ShowEmployes();
            System.out.println("Make Payment");
            Make_payment();
        }
    }
    public void Show_Events_booking()
    {
        System.out.println("You have booked: ");
        cf.readFromFileInfo();

    }
}


import java.io.*;
import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files
public class CreateFile {
    File fileObj = new File("Employee input.txt");		 //to creat a file
    public void writeInFile(String s)
    {
        try
        {
            if (fileObj.createNewFile()) {
                //to write in a file
                FileWriter writer = new FileWriter(fileObj, true);
                writer.write(s+"\r"+"\n");	//\r+\n is for creating new line
                writer.flush();
                writer.close();

                System.out.println("Details: \n" + fileObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void readFromFile()
    {
        try {
            Scanner myReader = new Scanner(fileObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }




    File fileObjinfo = new File("Event Info.txt");		 //to creat a file
    public void writeInFileInfo(String s)
    {
        try
        {
            if (fileObjinfo.createNewFile()) {
                //to write in a file
                FileWriter writer = new FileWriter(fileObjinfo, true);
                writer.write(s+"\r"+"\n");	//\r+\n is for creating new line
                writer.flush();
                writer.close();

                System.out.println("Details" + fileObjinfo.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void readFromFileInfo()
    {
        try {
            Scanner myReader = new Scanner(fileObjinfo);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    File fileprein = new File("Employee Info.txt");		 //to creat a file
    public void writeInFileprein(String s)
    {
        try
        {
            if (fileprein .createNewFile()) {
                //to write in a file
                FileWriter writer = new FileWriter(fileprein , true);
                writer.write(s+"\r"+"\n");	//\r+\n is for creating new line
                writer.flush();
                writer.close();

                System.out.println("Details" + fileprein .getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void readFromprein()
    {
        try {
            Scanner myReader = new Scanner(fileprein);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}



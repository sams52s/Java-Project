
import java.util.*;
public class Main {

    public static void main(String[] args) {
        LogIn login = new LogIn();
        Scanner objs=new Scanner(System.in);
        System.out.println("***********Welcome to cubic Event management***********");
        System.out.println("***********We can manage your event as you dream***********");
        System.out.println("\n1.Log IN");
        System.out.println("2.Sign In");
        int i1=objs.nextInt();
        if(i1==1) {
            
            login.TakeLogInInfo();
        }
        else if (i1==2)
        {
            System.out.println("\n............Sign In...................");
            SignIn sign = new SignIn();
            sign.setSignIn();

        }
        else{
            System.out.println("Wrong Input");
        }

    }
}

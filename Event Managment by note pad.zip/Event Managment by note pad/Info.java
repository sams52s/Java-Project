
import java.util.*;
public class Info {
    CreateFile cf = new CreateFile();
    Scanner objInfo1=new Scanner(System.in);
    public String sname;
    public String spassword;
    public String address;
    public String phone;
    public String email;
    public Info(){}

    public Info(String name, String address, String phone, String email) {
        setName(name);
        setAddress(address);
        setPhone(phone);
        setEmail(email);

    }

    public void setName(String name) {
        this.sname = name;
    }
    public void setPassword(String password) {
        this.spassword = password;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getName() {
        return sname;
    }
    public String getPassword() {
        return spassword;
    }
    public String getAddress()
    {
        return address;
    }

    public String getPhone() {
        return phone;
    }
    public String getEmail() {
        return email;
    }
    public void TakeInfo()
    {
        System.out.println("Your name: ");
        String n=objInfo1.nextLine();
        setName(n);
        System.out.println("password: ");
        String p=objInfo1.nextLine();
        setPassword(p);
        System.out.println("Address: ");
        String addr=objInfo1.nextLine();
        System.out.println("Phone Number: ");
        String phone=objInfo1.nextLine();
        System.out.println("Email : ");
        String email=objInfo1.nextLine();
        new Info(n,addr,phone,email);
        String i0 ="Name: "+n+"\nAddress: "+addr+"\nPhone Number: "+phone+"\nEmail: "+email;
        cf.writeInFileprein(i0);
    }
    public void GiveInfo() {
        cf.readFromprein();
    }

}

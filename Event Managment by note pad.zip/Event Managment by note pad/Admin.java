
class Admin extends Employee{

    CreateFile cf = new CreateFile();
    public void Employees() {
        // The body of animalSound() is provided here

        String i2 = "Manager: Turjo.\nDecorator: ali mia \nchafe: Imran \nPhotographer: Surjo  ";
        cf.writeInFileprein(i2);
    }
    public void ShowEmployes()
    {
        cf.readFromprein();
    }
    public void Events() {
        System.out.println("Our Up coming events are: \n31-12-2020 ->Wedding of Turjo.\n01-01-2021 -> Meeting for AIUB. ");
    }
    public void payEmployees()
    {
        Event e = new Event();
        int p=e.price;
        int m=p/6;
        int left=p-(m*4);
        System.out.println("Thank you for your payment "+p);
        System.out.println("Manager: Turjo will get: "+m);
        System.out.println("Decorator: ali mia will get: "+m);
        System.out.println("chafe: Imran  will get: "+m);
        System.out.println("Photographer: Surjo will get: "+m);
        System.out.println("I will get will get: "+left);
    }

}



public class User extends Event {
public  void  user()
{
    Events_available();
    /*System.out.println("Your Event will Manage by team1: \n");
    Admin admin = new Admin();
    admin.ShowEmployes();
    System.out.println("Make Payment");
    Make_payment();*/
}
}

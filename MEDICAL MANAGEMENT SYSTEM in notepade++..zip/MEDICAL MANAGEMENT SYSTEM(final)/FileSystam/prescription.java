package FileSystam;
import java.lang.*;
import java.io.*;

public class prescription extends mstore   //inheritance
{
	private File file; 			 //to creat a file
	private FileWriter writer; 	//to write in a file
	private FileReader reader;  //to read from a file
	private BufferedReader bfr; //to read file content
	public void medic()// Abstract method
	{
		System.out.println("Zimax 1+1+1  7day \r\n Fexo 0+1+1  7day");
		System.out.println("Bicozin 500 0+0+1  7day");
	}
	public void writeInFile(String s)
	{
		try
		{
			file = new File("prescription.txt");
			file.createNewFile();					
			writer = new FileWriter(file, true);
			writer.write(s+"\r"+"\n");	//\r+\n is for creating new line			
			writer.flush();
			writer.close();	
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public void readFromFile()
	{
		
		try
		{
			reader = new FileReader(file);
			bfr = new BufferedReader(reader);
			String text="", temp;
			
			while((temp=bfr.readLine())!=null)
			{
				text=text+temp+"\n"+"\r";
			}
			
			System.out.print(text); 
			reader.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
}
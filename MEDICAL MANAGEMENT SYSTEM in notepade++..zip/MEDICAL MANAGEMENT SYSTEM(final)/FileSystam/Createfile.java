package FileSystam;
import java.lang.*;
import java.io.*;
public class Createfile {
    boolean choice1=true;
    boolean choice2=true;
    boolean choice3=true;
    private File filedoc; 			 //to create a file
    private File filed; 			 //to create a file
    private File filep; 			 //to create a file
    private FileWriter writer; 	//to write in a file
    private FileReader reader;  //to read from a file
    private BufferedReader bfr; //to read file content

    public void writeInFileDoc(String s)
    {
        try
        {

            filedoc = new File("Doctor Info.txt");
            //\r+\n is for creating new line
            while(choice1){
                filedoc.createNewFile();
                choice1=false;
            }
            writer = new FileWriter(filedoc, true);
            writer.write(s + "\r" + "\n");    //\r+\n is for creating new line
            writer.flush();
            writer.close();

        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();

        }
    }

    public void readFromFileDoc()
    {

        try
        {
            reader = new FileReader(filedoc);
            bfr = new BufferedReader(reader);
            String text="", temp;

            while((temp=bfr.readLine())!=null)
            {
                text=text+temp+"\n"+"\r";
            }

            System.out.print(text);
            reader.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
    public void writeInFilep(String s)
    {
        try
        {
            filep = new File("Patient Info.txt");

            while(choice2){
                filep.createNewFile();
                choice2=false;
            }
            writer = new FileWriter(filep, true);
            writer.write(s+"\r"+"\n");	//\r+\n is for creating new line
            writer.flush();
            writer.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    public void readFromFilep()
    {

        try
        {
            reader = new FileReader(filep);
            bfr = new BufferedReader(reader);
            String text="", temp;

            while((temp=bfr.readLine())!=null)
            {
                text=text+temp+"\n"+"\r";
            }

            System.out.print(text);
            reader.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
    public void writeInFiled(String s)
    {
        try
        {
            filed = new File("Donor Info.txt");

            while(choice3){
                filed.createNewFile();
                choice3=false;
            }
            writer = new FileWriter(filed, true);
            writer.write(s+"\r"+"\n");	//\r+\n is for creating new line
            writer.flush();
            writer.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    public void readFromFiled()
    {

        try
        {
            reader = new FileReader(filed);
            bfr = new BufferedReader(reader);
            String text="", temp;

            while((temp=bfr.readLine())!=null)
            {
                text=text+temp+"\n"+"\r";
            }

            System.out.print(text);
            reader.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}

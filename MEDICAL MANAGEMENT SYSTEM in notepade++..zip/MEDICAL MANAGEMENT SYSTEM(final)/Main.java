//import Interface.*;
import AllClasses.*;
//import FileSystam.*;
import java.lang.*;
import java.util.*;
import java.io.*;
public class Main {



    public static void main(String[] args) {
        Info info = new Info();
        Page1 page1=new Page1();
        Scanner ob1 = new Scanner(System.in);
        Scanner ob2 = new Scanner(System.in);
        System.out.println("\t\t\t\n------WELCOME TO ONLINE MEDICAL MANAGEMENT SYSTEM------\n");
        int op1;
        boolean choice=true;
        while (choice) {
        	System.out.println("\n\n");
            info.takeOption();
            op1 = ob1.nextInt();
            page1.option(op1);
            if(op1==0)
            {
                choice=false;
            }
        }

    }

}

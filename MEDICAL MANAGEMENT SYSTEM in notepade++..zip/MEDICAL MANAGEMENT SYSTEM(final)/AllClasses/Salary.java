package AllClasses;
import FileSystam.*;
import Interface.*;

public class Salary  {
	private double basicAmount;
	private double festivalBonus;
	private double overtimeAmount;
    public double sal;
	public Salary(){
		
	}
	public Salary(double basicAmount, double festivalBonus, double overtimeAmount)
	{
		this.basicAmount=basicAmount;
        this.festivalBonus=festivalBonus;
        this.overtimeAmount=overtimeAmount;
        sal=basicAmount+festivalBonus+overtimeAmount;

	}
	public void setbasicAmount(double basicAmount)
    {
        this.basicAmount=basicAmount;
    }
    public void setfestivalBonus(double festivalBonus)
    {
        this.festivalBonus=festivalBonus;
    }
    public void setovertimeAmount(double overtimeAmount)
    {
        this.overtimeAmount=overtimeAmount;
    }
 
    public double getbasicAmount()
    {
        return this.basicAmount;
    }
    public double getfestivalBonus()
    {
        return this.festivalBonus;
    }
    public double getovertimeAmount()
    {
        return this.overtimeAmount;
    }
    public double getsal()
    {
        return this.sal;
    }
 
}
package AllClasses;
import FileSystam.*;
import Interface.*;
import java.util.Scanner;

public class Info {
   // Doctor d=new Doctor();
    Scanner ob1 = new Scanner(System.in);
    Scanner ob2 = new Scanner(System.in);
    Scanner ob3 = new Scanner(System.in);
    Createfile create = new Createfile();
    public String fp;
    public String f0;
    public String fd;
    private String name;
    private String NID;
    private String Phone;
    private String Mail;
    private String bloodGroup;
    private int age;

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setNID(String NID) {
        this.NID = NID;
    }

    public void setMail(String mail) {
        Mail = mail;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return Phone;
    }

    public String getNID() {
        return NID;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public String getMail() {
        return Mail;
    }

    public int getAge() {
        return age;
    }
    public void takeOption()
    {
        System.out.println("\t\t 1-> Doctor");
        System.out.println("\t\t 2-> Patient");
        System.out.println("\t\t 3-> Donor");
        System.out.println("\t\t 0-> Exit");
    }
    public void takeOption2()
    {
        System.out.println("\tYou Want to: ");
        System.out.println("\t\t\t\t 1.Add : ");
        System.out.println("\t\t\t\t 2.Remove : ");
        System.out.println("\t\t\t\t 3.Show all : ");
        System.out.println("\t\t\t\t 4.Go back : ");
        System.out.println("\t\t\t\t 0.Exit : ");
    }
    public void docExt()
    {
       System.out.println("Enter  your year Of Experience: ");
        /*int yearOfExperience = ob3.nextInt();
        d.yearOfExperience = yearOfExperience;
        System.out.println("Enter Your Degree: ");
        String deg = ob3.nextLine();
        d.setdeg(deg);
        System.out.println("Enter  your fee per patient: ");
        float fee = ob3.nextFloat();
        d.setfee(fee);
        Salary s = new Salary();
        final double basicAmount = 30000; //basicAmount is unchangable now.
        s.setbasicAmount(basicAmount);
        double f = basicAmount / 3;
        s.setfestivalBonus(f);
        System.out.println("Enter Your over Time houre : ");
        double h = ob3.nextDouble();
        double o = basicAmount / 50;
        double ov = h * o;
        s.setovertimeAmount(ov);
        Salary sal = new Salary(basicAmount, f, ov);
        d.setsal(sal);
        System.out.println("This Doctor All info: ");
        d.show();*/

    }

    public void TakeInfo()
    {
        System.out.println("Enter Your Name: ");
        String name = ob1.nextLine();
        setName(name);
        System.out.println("Enter Your NID: ");
        String nid = ob1.nextLine();
        setNID(nid);
        System.out.println("Enter Your Phone Number: ");
        String phone = ob1.nextLine();
        setPhone(phone);
        System.out.println("Enter Your Mail: ");
        String mail = ob1.nextLine();
        setMail(mail);
        try{
            System.out.println("Enter Your Age: ");
            int age = ob2.nextInt();
            setAge(age);
        }
        catch (Exception e)
        {
            System.out.println("Age must be in int value.");
        }
        System.out.println("Enter Your BloodGroup: ");
        String BloodGroup = ob1.nextLine();
        setBloodGroup(BloodGroup);
    }
    public void Show()
    {
        System.out.println("Your name: "+getName());
        System.out.println("Your NID: "+getNID() );
        System.out.println("Your Age: "+getAge());
        System.out.println("Your Mail: "+getMail() );
        System.out.println("Your Phone Number: "+getPhone());
        System.out.println("Your Blood group: "+getBloodGroup());
    }
    public void addTOfiledoc()
    {
            f0="Name: "+getName()+"\nNID: "+getNID()+"\nAge: "+getAge()+"\nMail: "+getMail()+"\nPhone Number: "+getPhone()+"\nBlood group: "+getBloodGroup();
            create.writeInFileDoc(f0);


    }
    public void addTOfilep()
    {
        fp="Name: "+getName()+"\nNID: "+getNID()+"\nAge: "+getAge()+"\nMail: "+getMail()+"\nPhone Number: "+getPhone()+"\nBlood group: "+getBloodGroup();
        create.writeInFilep(fp);
    }
    public void addTOfiled()
    {
        fd="Name: "+getName()+"\nNID: "+getNID()+"\nAge: "+getAge()+"\nMail: "+getMail()+"\nPhone Number: "+getPhone()+"\nBlood group: "+getBloodGroup();
        create.writeInFiled(fd);
    }


}

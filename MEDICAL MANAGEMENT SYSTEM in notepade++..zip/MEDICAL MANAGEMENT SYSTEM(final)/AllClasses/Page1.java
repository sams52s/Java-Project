package AllClasses;
import FileSystam.*;
import Interface.*;
import java.util.Scanner;
public class Page1 {

    public static void cls()
    {
        try
        {
            new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
        }catch(Exception E)
        {
            System.out.println(E);
        }
    }

    Scanner ob1 = new Scanner(System.in);
    Scanner ob2 = new Scanner(System.in);

    Createfile createfile=new Createfile();
    prescription pres=new prescription();

        Info info = new Info();
        public int oI;
        public void option(int optionI)
        {
            this.oI=optionI;
            switch (oI) {
                case 1 ->
                        {
                            System.out.println("\t\t\t\t\tDoctor:");
                            info.takeOption2();
                            int opd=ob2.nextInt();
                            if(opd==1)
                            {
                                info.TakeInfo();
                                info.addTOfiledoc();
                                info.docExt();
                                cls();

                            }
                            else if(opd==2)
                            {
                                cls();
                                System.out.println("Ok");
                            }
                            else if(opd==3)
                            {
                                System.out.println("All doctor info: ");
                                info.Show();
                                createfile.readFromFileDoc();

                            }
                            else if(opd==4)
                            {
                                cls();
                                info.takeOption();
                                int op1=ob1.nextInt();
                                option(op1);

                            }
                            else if(opd==0)
                            {
                                cls();
                                System.out.println("Thank you have a nice day.");
                            }
                            else{
                                System.out.println("Sorry Wrong input.");
                            }
                        }
                case 2 -> {
                    cls();
                    System.out.println("\t\t\t\t\tPatient::");
                    info.takeOption2();
                    System.out.println("5.Prescription: ");
                    int opd=ob2.nextInt();
                    if(opd==1)
                    {
                        info.TakeInfo();
                        info.addTOfilep();
                    }
                    else if(opd==2)
                    {
                        System.out.println("Ok");
                    }
                    else if(opd==3)
                    {
                        System.out.println("All Patient info: ");
                        createfile.readFromFilep();
                    }
                    else if(opd==4)
                    {
                        info.takeOption();
                        int op1=ob1.nextInt();
                        option(op1);

                    }
                    else if(opd==5)
                    {
                        System.out.println("1 -> medicine: ");
                        System.out.println("2 -> Purchase Plasma: ");
                        int pl = ob2.nextInt();
                        if (pl == 1) {
                            pres.medic();// Abstract method
                        }
                        if (pl == 2) {
                            pres.bill();
                        }

                    }
                    else if(opd==0)
                    {
                        System.out.println("Thank you have a nice day.");
                    }
                    else{
                        System.out.println("Sorry Wrong input.");
                    }
                }
                case 3 -> {
                    cls();
                    System.out.println("\t\t\t\t\tDonor ::");
                    info.takeOption2();
                    int opd=ob2.nextInt();
                    if(opd==1)
                    {
                        info.TakeInfo();
                        info.addTOfiled();
                    }
                    else if(opd==2)
                    {
                        System.out.println("Ok");
                    }
                    else if(opd==3)
                    {
                        System.out.println("All Donor info: ");
                        createfile.readFromFiled();
                    }
                    else if(opd==4)
                    {
                        info.takeOption();
                        int op1=ob1.nextInt();
                        option(op1);

                    }
                    else if(opd==0)
                    {
                        cls();
                        System.out.println("Thank you have a nice day.");
                    }
                    else{
                        System.out.println("Sorry Wrong input.");
                    }
                }
                case 0 -> {cls();
                    System.out.println("Thank you have a nice day.");
                }
                default -> System.out.println("\t\t\tWrong Input....");
            }
        }
    }



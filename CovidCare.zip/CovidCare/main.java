//This main class.
import java.lang.*;
import java.util.*;
import java.io.*;
import java.util.Scanner;
public class main
{
	public static void main(String args[])
   {
	Scanner ob = new Scanner(System.in);
	Scanner ob2 = new Scanner(System.in);
	prescription pres=new prescription();
	Medical m=new Medical();
	Donor Don = new Donor();

	System.out.println("               ***Welcome To Covid Care***                        \n");
	boolean choice=true;
	while (choice)
	{
	System.out.println("\r\n ");
	System.out.println("1->   Doctor: ");
	System.out.println("2->   Patient: ");
	System.out.println("3->   Donate Plasma: ");
	System.out.println("5->   Admin: ");
	System.out.println("0->   Exit: ");
	int choice1=ob.nextInt();
	switch(choice1)
	{

		case 1:
		{
			System.out.println("\n  Doctor ");

			System.out.println("1-> creat ID: ");
			System.out.println("2-> Login: ");
			System.out.println("0-> Back: ");
			int choice2=ob.nextInt();
			switch(choice2)
			{

				case 1:
				{
					System.out.println("Enter Your info : ");
					Scanner obn=new Scanner(System.in);
					Scanner obs=new Scanner(System.in);
					Scanner obi=new Scanner(System.in);
					Scanner obf=new Scanner(System.in);
					Doctor d=new Doctor();
					System.out.println("Enter Your First Name: ");
					String FirstName = obn.nextLine();
					d.FirstName=FirstName;
					System.out.println("Enter Your Last Name: ");
					String LastName = obn.nextLine();
					d.LastName=LastName;
					System.out.println("Enter Your ID: ");
					String id=obs.nextLine();
					d.id=id;
					System.out.println("Enter Your Phone Number: ");
					String pnum = obs.nextLine();
					d.setpnum(pnum);
					System.out.println("Enter Your PassWoard: ");
					String pass = obs.nextLine();
					d.setpnum(pass);
					System.out.println("Enter Your Email: ");
					String email = obs.nextLine();
					d.setemail(email);
					System.out.println("Enter  your Age: ");
					int age=obi.nextInt();
					d.setage(age);
					System.out.println("Enter Your bloodGroup: ");
					String bloodGroup=obs.nextLine();
					d.bloodGroup=bloodGroup;
					System.out.println("Enter  your year Of Experience: ");
					int yearOfExperience=obi.nextInt();
					d.yearOfExperience=yearOfExperience;
					System.out.println("Enter Your Degree: ");
					String deg=obs.nextLine();
					d.setdeg(deg);
					System.out.println("Enter  your fee per patient: ");
					float fee=obf.nextFloat();
					d.setfee(fee);	
					
					Salary s= new Salary();
					final double basicAmout=30000; //basicAmount is unchangable now.
					s.setbasicAmount(basicAmout);
					double f=basicAmout/3;
					s.setfestivalBonus(f);
					System.out.println("Enter Your over Time houre : ");
					double h=obf.nextDouble();
					double o=basicAmout/50;
					double ov=h*o;
					s.setovertimeAmount(ov);
					Salary sal= new Salary(basicAmout,f,ov);
					d.setsal(sal);
					d.show();	
					Doctor dd = new Doctor("Sadia ","mim","D-22002", "+88017111096695","22d","Diner111@gmail.com",45,"O+",5,600,"FCPS",sal);
					Doctor ddd = new Doctor("Fatima ","Koli","D-22003", "+880179999996695","23k","Koli9999@gmail.com",30,"AB+",3,400,"MBBS",sal);
					break;
				}
				case 2:
				{
					System.out.println("Enter Your ID: ");
					int id=ob2.nextInt();
					System.out.println("Your Pass: ");
					int pass=ob2.nextInt();


					if(id==2 && pass==2 )
					{

					 	System.out.println("Your Loged in: ");
					 	System.out.println("Write a prescription: ");
					 	pres.writeInFile("LORA  1+1+1  7day \r\n Monas 0+1+1  7day");
					 	pres.writeInFile("ODAZ 500 0+0+1  7day");
					 	System.out.println("\n prescription : ");
					 	pres.readFromFile();// file system
					}
					else
						{
						System.out.println("This ID is not valide");
						}

					break;
				}
				case 0:
				{
					System.out.println("\n >>>>> Going Back>>>>>>>>>> \n");
					break;
				}
				default:
				
					System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
					
				break;
			}
				break;
		}
		case 2: 
			{
				System.out.println("\n Patient");
				System.out.println("1 -> create ID: ");
				System.out.println("2 -> Login: ");
				System.out.println("0-> Back: ");
				int choice3=ob.nextInt();
				switch(choice3)
				{
					case 1:
					{
						System.out.println("Create Id: ");
						Scanner ob1 = new Scanner(System.in);
						Patient p=new Patient();
						System.out.println("Enter Your First Name: ");
						String FirstName = ob1.nextLine();
						p.FirstName=FirstName;
						System.out.println("Enter Your Last Name: ");
						String LastName = ob1.nextLine();
						p.LastName=LastName;
						System.out.println("Enter Your ID: ");
						String id=ob1.nextLine();
						p.id=id;
						System.out.println("Enter Your bloodGroup: ");
						String bloodGroup=ob1.nextLine();
						p.bloodGroup=bloodGroup;
						System.out.println("Enter Your Phone Number: ");
						String pnum = ob1.nextLine();
						p.setpnum(pnum);
						System.out.println("Enter Your PassWoard: ");
						String pass = ob1.nextLine();
						p.setpnum(pass);
						System.out.println("Enter Your Email: ");
						String email = ob1.nextLine();
						p.setemail(email);
						System.out.println("Enter  your Age: ");
						int age=ob1.nextInt();
						p.setage(age);
						System.out.println("Your Info: ");
						p.show();
						break;
					}
					case 2:
					{
						System.out.println("1 -> medicine: ");
						System.out.println("2 -> Purchase Plasma: ");
						int pl=ob2.nextInt();
						if (pl==1)
						{
							pres.medic();// Abstract method
						}
						if (pl==2)
						{
							pres.bill();
						}
						break;
					}
					case 0:
					{
						System.out.println("\n >>>> Backing >>>> \n");
						
						break;
					}
					default:
				
					System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
					
					break;
				}
				break;
			}
		case 3:
		{
						System.out.println("Create Id: ");
						Scanner ob1 = new Scanner(System.in);
						Donor p=new Donor();
						System.out.println("Enter Your First Name: ");
						String FirstName = ob1.nextLine();
						p.FirstName=FirstName;
						System.out.println("Enter Your Last Name: ");
						String LastName = ob1.nextLine();
						p.LastName=LastName;
						System.out.println("Enter Your ID: ");
						String id=ob1.nextLine();
						p.id=id;
						System.out.println("Enter Your bloodGroup: ");
						String bloodGroup=ob1.nextLine();
						p.bloodGroup=bloodGroup;
						System.out.println("Enter Your Phone Number: ");
						String pnum = ob1.nextLine();
						p.setpnum(pnum);
						System.out.println("Enter Your PassWoard: ");
						String pass = ob1.nextLine();
						p.setpnum(pass);
						System.out.println("Enter Your Email: ");
						String email = ob1.nextLine();
						p.setemail(email);
						System.out.println("Enter  your Age: ");
						int age=ob1.nextInt();
						p.setage(age);
						System.out.println("Your Info: ");
						p.show();
						break;
		}		
		case 5:
		{
			System.out.println("1-> Add Doctor: ");
			System.out.println("2-> Remove Doctor: ");
			int i=ob2.nextInt();
			if(i==1)
			{
				Doctor dx=new Doctor();
				dx.Numberofdoctor();
					m.add();
					m.arr();
			}
			if(i==2){
				m.remove();
			}
			break;
					
		}
	    case 0:
				{
					System.out.println("\n >>>>>>>>>>> System Exit>>>>>>> \n");
					System.exit(0);
					break;
				}
	    default:
		System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
		break;
	}
}



}
}
	
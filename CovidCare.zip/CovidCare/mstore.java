// Abstract class
import java.lang.*;
import java.util.*;
import java.io.*;
import java.util.Scanner;
abstract class mstore{
	public abstract void medic();// Abstract method
	public  void bill() // Regular method and alsao a final method.
	{

		Scanner sc = new Scanner(System.in);
    	int wantedbloodgroup;
        System.out.println("\nThe blood group you want :\nChoose from: \n1.A+ \n2.A- \n3.B+ \n4.B- \n5.O+ \n6.O- \n7.AB+ \n8.AB-\n");
        wantedbloodgroup = sc.nextInt();
        
        switch(wantedbloodgroup)
        {
            case 1:
            {
                System.out.println("");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : A+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 2:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : A-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 3:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : B+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 4:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : B-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 5:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : O+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 6:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : O-");
                System.out.println("\nCost : Rs 5000/-\n");
                break;
            }
                 case 7:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : AB+");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
                 case 8:
            {
                System.out.println("       Blood Bank     ");
                System.out.println("\nBill");
                System.out.println("\nBlood group you wanted : AB-");
                System.out.println("\nCost : Rs 1000/-\n");
                break;
            }
        }
	}

}
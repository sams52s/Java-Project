//This Employee salary class.
public class Salary  {
	private double basicAmout;
	private double festivalBonus;
	private double overtimeAmount;
    public double sal;
	public Salary(){
		
	}
	public Salary(double basicAmout, double festivalBonus, double overtimeAmount)
	{
		this.basicAmout=basicAmout;
        this.festivalBonus=festivalBonus;
        this.overtimeAmount=overtimeAmount;
        sal=basicAmout+festivalBonus+overtimeAmount;

	}
	public void setbasicAmount(double basicAmout)
    {
        this.basicAmout=basicAmout;
    }
    public void setfestivalBonus(double festivalBonus)
    {
        this.festivalBonus=festivalBonus;
    }
    public void setovertimeAmount(double overtimeAmount)
    {
        this.overtimeAmount=overtimeAmount;
    }
 
    public double getbasicAmount()
    {
        return this.basicAmout;
    }
    public double getfestivalBonus()
    {
        return this.festivalBonus;
    }
    public double getovertimeAmount()
    {
        return this.overtimeAmount;
    }
    public double getsal()
    {
        return this.sal;
    }
 
}
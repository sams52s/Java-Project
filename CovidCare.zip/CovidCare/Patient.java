//This Patient(Child class of a Info) class.
public class Patient  extends Info
{
	//protected String ID;
	public Patient(){
		
	}
	public Patient(String FirstName,String LastName,String id,String pnum,String pass,String email,int age,String bloodGroup,String ID)
	{
		super(FirstName, LastName,id, pnum,pass, email, age, bloodGroup);

	}
	public void show()
	{
		super.show();
	}
}
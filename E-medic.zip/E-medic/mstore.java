// Abstract class
abstract class mstore{
	public abstract void medic();// Abstract method
	public  void bill() // Regular method and alsao a final method.
	{

		System.out.println("Toall bill: 500/- ");


	}


}
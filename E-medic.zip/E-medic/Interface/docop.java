package Interface;
import java.lang.*;
import java.util.*;
import java.io.*;

public interface docop
{
	public void add();
	public void remove();

}
//This Info class.
public class Info{
	public String FirstName;
	public String LastName;
	protected String id; //protected var
	private String pnum;
	private String pass;
	private String email;
	private	int age  ;
	public String bloodGroup;
	public Info()
	{
		
	}
	public Info(String FirstName,String LastName,String id,String pnum,String pass,String email,int age,String bloodGroup)
	{
		this.FirstName=FirstName;
		this.LastName=LastName;
		this.id=id;
		this.pnum=pnum;
		this.email=email;
		this.age=age;
		this.bloodGroup=bloodGroup;
	}
	public void setid(String id)
	{
		this.id=id;
	}
	public String getid()
	{
		return this.id;
	}	
	public void setage(int age)
	{
		this.age=age;
	}
	public int getage()
	{
		return this.age;
	}

	public void setpnum(String pnum)
	{
		this.pnum=pnum;
	}
	public String getpnum()
	{
		return this.pnum;
	}
		public void setpass(String pass)
	{
		this.pass=pass;
	}
	public String getpass()
	{
		return this.pass;
	}
		public void setemail(String email)
	{
		this.email=email;
	}
	public String getemail()
	{
		return this.email;
	}
	
	public void show()
	{
		System.out.println("Your FirstName: "+this.FirstName);
		System.out.println("Your LastName: "+this.LastName);
		System.out.println("Your Phone Number: "+getid());
		System.out.println("Your Phone Number: "+getpnum());
		System.out.println("Your Email: "+getemail());
		System.out.println("Your age: "+getage());
		System.out.println("Your bloodGroup: "+this.bloodGroup);
	}

}
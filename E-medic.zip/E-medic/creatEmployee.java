
import java.util.Scanner;
public class creatEmployee extends Employee {
	Employee e=new Employee();
	public void ce ()
    {
		Scanner ob1 = new Scanner(System.in);
        EmpSalary s= new EmpSalary();
		double basicAmout=9999;
		s.setbasicAmount(basicAmout);
		double f=basicAmout/3;
		s.setfestivalBonus(f);
		System.out.println("Enter Your over Time houre : ");
		double h=ob1.nextDouble();
		double o=basicAmout/50;
		double ov=h*o;
		s.setovertimeAmount(ov);
		EmpSalary sal= new EmpSalary(basicAmout,f,ov);
		Employee emp = new Employee("Kakoli","khatun","E-15003", "+8801750096695","53e","Kakoli95@gmail.com",20,"A+",sal);
        emp.show(); 
    }
	
}
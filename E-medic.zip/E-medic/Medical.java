import java.lang.*;
import java.util.*;
import java.io.*;
import Interface.*;
public class Medical implements docop
{
	public void arr(){
		String[] docc={"shanjida","sams"};
		System.out.println("doctor : "+docc[0]);
	} 

	public void add()
	{
		System.out.println("A Doctor added");
	}
	public void remove()
	{
		System.out.println("A Doctor removed");
	}


}
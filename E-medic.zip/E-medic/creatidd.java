import java.util.Scanner;
import java.lang.*;
import java.util.*;
import java.io.*;
public class creatidd extends Doctor{
	Doctor d=new Doctor();
	
	public void doc()
	{
		Scanner obn=new Scanner(System.in);
		Scanner obs=new Scanner(System.in);
		Scanner obi=new Scanner(System.in);
		Scanner obf=new Scanner(System.in);
		//Doctor d=new Doctor();
		System.out.println("Enter Your First Name: ");
		String FirstName = obn.nextLine();
		d.FirstName=FirstName;
		System.out.println("Enter Your Last Name: ");
		String LastName = obn.nextLine();
		d.LastName=LastName;
		System.out.println("Enter Your ID: ");
		String id=obs.nextLine();
		d.id=id;
		System.out.println("Enter Your Phone Number: ");
		String pnum = obs.nextLine();
		d.setpnum(pnum);
		System.out.println("Enter Your PassWoard: ");
		String pass = obs.nextLine();
		d.setpnum(pass);
		System.out.println("Enter Your Email: ");
		String email = obs.nextLine();
		d.setemail(email);
		System.out.println("Enter  your Age: ");
		int age=obi.nextInt();
		d.setage(age);
		System.out.println("Enter Your bloodGroup: ");
		String bloodGroup=obs.nextLine();
		d.bloodGroup=bloodGroup;
		System.out.println("Enter  your year Of Experience: ");
		int yearOfExperience=obi.nextInt();
		d.yearOfExperience=yearOfExperience;
		System.out.println("Enter Your Degree: ");
		String deg=obs.nextLine();
		d.setdeg(deg);
		System.out.println("Enter  your fee per patient: ");
		float fee=obf.nextFloat();
		d.setfee(fee);	
		
		EmpSalary s= new EmpSalary();
		final double basicAmout=30000; //basicAmount is unchangable now.
		s.setbasicAmount(basicAmout);
		double f=basicAmout/3;
		s.setfestivalBonus(f);
		System.out.println("Enter Your over Time houre : ");
		double h=obf.nextDouble();
		double o=basicAmout/50;
		double ov=h*o;
		s.setovertimeAmount(ov);
		EmpSalary sal= new EmpSalary(basicAmout,f,ov);
		d.setsal(sal);
		d.show();	
		Doctor dd = new Doctor("Toriqul ","Diner","D-22002", "+88017111096695","22d","Diner111@gmail.com",45,"O+",5,600,"FCPS",sal);
		Doctor ddd = new Doctor("Fatima ","Koli","D-22003", "+880179999996695","23k","Koli9999@gmail.com",30,"AB+",3,400,"MBBS",sal);


	}
}

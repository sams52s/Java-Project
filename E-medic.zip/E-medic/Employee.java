
import java.lang.*;
import java.util.*;
import java.io.*;

public class Employee extends Info{
	private EmpSalary salary;
	ForCreateFile fob=new ForCreateFile();	

	public Employee()
	{
		
	}
	
	public Employee(String FirstName,String LastName,String id,String pnum,String pass,String email,int age,String bloodGroup,EmpSalary salary)
	{
		super(FirstName, LastName, id, pnum,pass, email, age, bloodGroup);
		this.salary=salary;
		fob.writeInFile("Name:korim khan \r\n ID: E-15001 \r\n Phone number: +8801750096000 \r\n email:  korim95@gmail.com \r\n Age: 20 \r\n Blood Group:  A+ \r\n Salary : 10000");
		fob.writeInFile("Name:Rohim khan \r\n ID: E-15002 \r\n Phone number: +8801750096111 \r\n email:  rohim95@gmail.com \r\n Age: 20 \r\n Blood Group:  B+ \r\n Salary : 10000");
	
	}
		void setsal(EmpSalary salary)
	{
		this.salary=salary;
	}
	EmpSalary getsal()
	{
		return this.salary;
	}
	public void show()
	{
		
		super.show();
		System.out.println("Salary: "+salary.getbasicAmount()+ " Festival Bonus is 1/2 of basic Amout: "+salary.getfestivalBonus() + " Over Time  Amout is: "+salary.getovertimeAmount());
		System.out.println("Totall Salary: "+salary.getsal());	
		fob.readFromFile();

		
	}
}
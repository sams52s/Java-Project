import java.util.Scanner;
import java.lang.*;
import java.util.*;
import java.io.*;
public class creatidp extends Patient{
	Scanner ob1 = new Scanner(System.in);
	public void p()
	{
		Patient p=new Patient();
		System.out.println("Enter Your First Name: ");
		String FirstName = ob1.nextLine();
		p.FirstName=FirstName;
		System.out.println("Enter Your Last Name: ");
		String LastName = ob1.nextLine();
		p.LastName=LastName;
		System.out.println("Enter Your ID: ");
		String id=ob1.nextLine();
		p.id=id;
		System.out.println("Enter Your bloodGroup: ");
		String bloodGroup=ob1.nextLine();
		p.bloodGroup=bloodGroup;
		System.out.println("Enter Your Phone Number: ");
		String pnum = ob1.nextLine();
		p.setpnum(pnum);
		System.out.println("Enter Your PassWoard: ");
		String pass = ob1.nextLine();
		p.setpnum(pass);
		System.out.println("Enter Your Email: ");
		String email = ob1.nextLine();
		p.setemail(email);
		System.out.println("Enter  your Age: ");
		int age=ob1.nextInt();
		p.setage(age);
		System.out.println("Your Info: ");
		p.show();
		

	}
}


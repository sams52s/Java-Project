//This main class.
import java.lang.*;
import java.util.*;
import java.io.*;
import java.util.Scanner;
public class main
{
	public static void main(String args[])
   {
	Scanner ob1 = new Scanner(System.in);
	Scanner ob2 = new Scanner(System.in);

	creatidd d=new creatidd();
	creatidp p=new creatidp();
	prescription pres=new prescription();
	Medical m=new Medical();

	System.out.println("               ***Welcome To E-medic***                        \n");
	boolean choice=true;
	while (choice)
	{
	System.out.println("\r\n ");
	System.out.println("Press 1 If you are Doctor: ");
	System.out.println("Press 2 If you are Patient: ");
	System.out.println("Press 3 For Employee info: ");
	System.out.println("Press 5 For Admin: ");
	System.out.println("Press 0 For Exit: ");
	int choice1=ob1.nextInt();
	switch(choice1)
	{

		case 1:
		{
			System.out.println("..........  Doctor .........");

			System.out.println("Press 1 For creat ID: ");
			System.out.println("Press 2 For Login: ");
			System.out.println("Press 0 Back: ");
			int choice2=ob1.nextInt();
			switch(choice2)
			{

				case 1:
				{
					System.out.println("Creat Id: ");
					d.doc();
					break;
				}
				case 2:
				{
					System.out.println("Enter Your ID: ");
					int id=ob2.nextInt();
					System.out.println("Your Pass: ");
					int pass=ob2.nextInt();


					if(id==2 && pass==2 )
					{

					 	System.out.println("Your Loged in: ");
					 	System.out.println("Write a prescription For Patient Number 1 : ");
					 	pres.writeInFile("Maxpro 1+0+1  5day \r\n Napa 0+1+1  4 day");
					 	pres.writeInFile("Zemax 0+1+0  3day ");
					 	System.out.println("prescription : ");
					 	pres.readFromFile();// file system
					}
					else
						{
						System.out.println("This ID is not valide");
						}

					break;
				}
				case 0:
				{
					System.out.println("\n ..................Backing.................. \n");
					break;
				}
				default:
				
					System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
					
				break;
			}
				break;
		}
		case 2: 
			{
				System.out.println("..................Patient...................");
				System.out.println("Press 1 For create ID: ");
				System.out.println("Press 2 For Login: ");
				System.out.println("Press 0 Back: ");
				int choice3=ob1.nextInt();
				switch(choice3)
				{
					case 1:
					{
						System.out.println("Create Id: ");
						p.p();
						break;
					}
					case 2:
					{
						System.out.println("Your login: ");
						pres.medic();// Abstract method
						pres.bill();
						break;
					}
					case 0:
					{
						System.out.println("\n ..................Backing.................. \n");
						
						break;
					}
					default:
				
					System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
					
					break;
				}
				break;
			}

		case 3:
				{
					creatEmployee e=new creatEmployee();
					System.out.println("Employee info: ");
					e.ce();
					break;
				}
		case 5:
		{
			System.out.println("1.Add Doctor: ");
			System.out.println("2.Remove Doctor: ");
			int i=ob2.nextInt();
			if(i==1)
			{
				Doctor dx=new Doctor();
				dx.Numberofdoctor();
					m.add();
					m.arr();
			}
			if(i==2){
				m.remove();
			}
			break;
					
		}
	    case 0:
				{
					System.out.println("\n ..................Have a good time.................. \n");
					System.exit(0);
					break;
				}
	    default:
		System.out.println("\nINVALID OPTION !!! \nCAUSE THIS OPTION IS GIVEN \nPLEASE CHOOSE OPTION AGAIN\n");
		break;
	}
}



}
}
	